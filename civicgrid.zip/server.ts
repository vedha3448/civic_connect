import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express, { type NextFunction, type Request, type Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import type {
  AiIssueAnalysis,
  AnalyticsSummary,
  AuthUser,
  Complaint,
  ComplaintStatus,
  IssueCategory,
  IssuePriority,
  UserRole,
} from './src/types/civic.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_PATH = path.resolve(DATA_DIR, 'civicgrid-db.json');
const UPLOADS_DIR = path.resolve(__dirname, 'uploads');

const VALID_CATEGORIES: IssueCategory[] = [
  'Pothole',
  'Garbage',
  'Damaged Road',
  'Streetlight',
  'Dustbin',
];

const VALID_STATUSES: ComplaintStatus[] = [
  'Submitted',
  'Under Review',
  'Assigned',
  'In Progress',
  'Resolved',
];

const VALID_PRIORITIES: IssuePriority[] = ['Low', 'Medium', 'High', 'Critical'];

const SESSION_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.trim().length >= 16
    ? process.env.SESSION_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

interface StoredUser {
  uid: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  createdAt: string;
}

interface DatabaseSchema {
  sequenceCounter: number;
  adminCredentialHash: string | null;
  users: StoredUser[];
  complaints: Complaint[];
}

function ensureDirectories(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

function createInitialSeedData(): DatabaseSchema {
  return {
    sequenceCounter: 5,
    adminCredentialHash: null,
    users: [],
    complaints: [
      {
        complaintId: 'CG-20261124-0001',
        category: 'Pothole',
        description:
          'Deep asphalt crater near the eastbound bus stop lane causing heavy braking and two-wheeler skids during peak traffic.',
        area: 'Indiranagar 100ft Road',
        photoURL: '/src/assets/images/issue_pothole_road_1795515516555.jpg',
        latitude: 12.9784,
        longitude: 77.6408,
        status: 'In Progress',
        priority: 'High',
        assignedDepartment: 'Road Maintenance Unit',
        adminNotes: 'Patch crew dispatched with hot-mix asphalt unit.',
        userId: 'seed-citizen-1',
        reporterName: 'Ananya R.',
        upvotes: 14,
        upvotedBy: ['seed-citizen-1'],
        aiClassified: true,
        createdAt: '2026-11-22T09:15:00.000Z',
        updatedAt: '2026-11-23T14:40:00.000Z',
        statusHistory: [
          {
            status: 'Submitted',
            note: 'Complaint registered with GPS pin and photographic evidence.',
            updatedAt: '2026-11-22T09:15:00.000Z',
            updatedBy: 'Citizen Portal',
          },
          {
            status: 'Under Review',
            note: 'Verified hazard proximity to bus bay.',
            updatedAt: '2026-11-22T11:20:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
          {
            status: 'Assigned',
            note: 'Assigned to Road Maintenance Unit (Zone East-4).',
            updatedAt: '2026-11-23T08:30:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
          {
            status: 'In Progress',
            note: 'Patch crew dispatched with hot-mix asphalt unit.',
            updatedAt: '2026-11-23T14:40:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
        ],
      },
      {
        complaintId: 'CG-20261124-0002',
        category: 'Garbage',
        description:
          'Uncollected domestic waste bags accumulated for 3 days along the residential brick compound wall, blocking pedestrian footpath.',
        area: 'Koramangala 4th Block',
        photoURL: '/src/assets/images/issue_garbage_pile_1795515516238.jpg',
        latitude: 12.9352,
        longitude: 77.6245,
        status: 'Assigned',
        priority: 'High',
        assignedDepartment: 'Sanitation & Solid Waste',
        adminNotes: 'Scheduled morning compactor pickup route 12B.',
        userId: 'seed-citizen-2',
        reporterName: 'Rohan M.',
        upvotes: 9,
        upvotedBy: ['seed-citizen-2'],
        aiClassified: true,
        createdAt: '2026-11-23T07:45:00.000Z',
        updatedAt: '2026-11-23T16:10:00.000Z',
        statusHistory: [
          {
            status: 'Submitted',
            note: 'Report logged by neighborhood resident.',
            updatedAt: '2026-11-23T07:45:00.000Z',
            updatedBy: 'Citizen Portal',
          },
          {
            status: 'Under Review',
            note: 'Sanitation supervisor reviewed uploaded street photo.',
            updatedAt: '2026-11-23T12:00:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
          {
            status: 'Assigned',
            note: 'Scheduled morning compactor pickup route 12B.',
            updatedAt: '2026-11-23T16:10:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
        ],
      },
      {
        complaintId: 'CG-20261124-0003',
        category: 'Streetlight',
        description:
          'Municipal LED pole #SL-409 is completely dark after sunset, leaving the crosswalk approach poorly lit for pedestrians.',
        area: 'Jayanagar 3rd Block',
        photoURL: '/src/assets/images/issue_streetlight_dark_1795515516521.jpg',
        latitude: 12.9299,
        longitude: 77.5848,
        status: 'Under Review',
        priority: 'Medium',
        assignedDepartment: 'Electrical & Streetlight Wing',
        adminNotes: 'Awaiting feeder line continuity test.',
        userId: 'seed-citizen-3',
        reporterName: 'Meera K.',
        upvotes: 6,
        upvotedBy: ['seed-citizen-3'],
        aiClassified: false,
        createdAt: '2026-11-23T18:30:00.000Z',
        updatedAt: '2026-11-24T01:10:00.000Z',
        statusHistory: [
          {
            status: 'Submitted',
            note: 'Nighttime visibility hazard reported.',
            updatedAt: '2026-11-23T18:30:00.000Z',
            updatedBy: 'Citizen Portal',
          },
          {
            status: 'Under Review',
            note: 'Awaiting feeder line continuity test.',
            updatedAt: '2026-11-24T01:10:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
        ],
      },
      {
        complaintId: 'CG-20261124-0004',
        category: 'Dustbin',
        description:
          'Public street litter bin outside commercial plaza is overflowing onto the paved walkway with food containers and cups.',
        area: 'MG Road Plaza',
        photoURL: '/src/assets/images/issue_overflowing_dustbin_1795515517332.jpg',
        latitude: 12.9756,
        longitude: 77.6066,
        status: 'Resolved',
        priority: 'Medium',
        assignedDepartment: 'Sanitation & Solid Waste',
        adminNotes: 'Bin cleared, area swept, and liner replaced.',
        userId: 'seed-citizen-4',
        reporterName: 'Vikram S.',
        upvotes: 11,
        upvotedBy: ['seed-citizen-4'],
        aiClassified: true,
        createdAt: '2026-11-21T10:05:00.000Z',
        updatedAt: '2026-11-22T06:20:00.000Z',
        statusHistory: [
          {
            status: 'Submitted',
            note: 'Overflowing bin reported near crosswalk.',
            updatedAt: '2026-11-21T10:05:00.000Z',
            updatedBy: 'Citizen Portal',
          },
          {
            status: 'Assigned',
            note: 'Dispatched central zone sanitation cart.',
            updatedAt: '2026-11-21T13:15:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
          {
            status: 'Resolved',
            note: 'Bin cleared, area swept, and liner replaced.',
            updatedAt: '2026-11-22T06:20:00.000Z',
            updatedBy: 'CivicGrid Dispatch',
          },
        ],
      },
      {
        complaintId: 'CG-20261124-0005',
        category: 'Damaged Road',
        description:
          'Severe surface cracking and sunken shoulder along a 15-meter stretch near the school zone junction after recent rains.',
        area: 'Malleshwaram 8th Cross',
        photoURL: '/src/assets/images/issue_pothole_road_1795515516555.jpg',
        latitude: 13.0031,
        longitude: 77.5701,
        status: 'Submitted',
        priority: 'Critical',
        userId: 'seed-citizen-5',
        reporterName: 'Deepa N.',
        upvotes: 18,
        upvotedBy: ['seed-citizen-5'],
        aiClassified: false,
        createdAt: '2026-11-24T01:55:00.000Z',
        updatedAt: '2026-11-24T01:55:00.000Z',
        statusHistory: [
          {
            status: 'Submitted',
            note: 'Submitted near school crossing for priority inspection.',
            updatedAt: '2026-11-24T01:55:00.000Z',
            updatedBy: 'Citizen Portal',
          },
        ],
      },
    ],
  };
}

function loadDatabase(): DatabaseSchema {
  ensureDirectories();
  if (!fs.existsSync(DB_PATH)) {
    const seeded = createInitialSeedData();
    fs.writeFileSync(DB_PATH, JSON.stringify(seeded, null, 2), 'utf8');
    return seeded;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  return JSON.parse(raw) as DatabaseSchema;
}

function saveDatabase(db: DatabaseSchema): void {
  ensureDirectories();
  const tempPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tempPath, DB_PATH);
}

let dbState: DatabaseSchema = loadDatabase();

// SSE clients for live public and admin dashboard updates
const sseClients = new Set<Response>();

function broadcastEvent(event: string, payload: unknown): void {
  const serialized = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of sseClients) {
    client.write(serialized);
  }
}

// Password hashing & token helpers
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  const expected = Buffer.from(keyHex, 'hex');
  const actual = crypto.scryptSync(password, salt, 64);
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(expected, actual);
}

function safeCompareString(a: string, b: string): boolean {
  const hashA = crypto.createHash('sha256').update(a).digest();
  const hashB = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

interface TokenPayload {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  exp: number;
}

function signToken(user: AuthUser): string {
  const payload: TokenPayload = {
    uid: user.uid,
    name: user.name,
    email: user.email,
    role: user.role,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): AuthUser | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return null;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  if (!safeCompareString(sig, expectedSig)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenPayload;
    if (!parsed.exp || parsed.exp < Date.now()) return null;
    if (!parsed.uid || !parsed.role) return null;
    return {
      uid: parsed.uid,
      name: parsed.name,
      email: parsed.email,
      role: parsed.role,
    };
  } catch {
    return null;
  }
}

interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

function extractBearerUser(req: Request): AuthUser | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  const token = header.slice(7).trim();
  if (!token) return null;
  return verifyToken(token);
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const user = extractBearerUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  req.user = user;
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const user = extractBearerUser(req);
  if (!user) {
    res.status(401).json({ error: 'Admin authentication required.' });
    return;
  }
  if (user.role !== 'admin') {
    res.status(403).json({ error: 'Administrator privileges are required for this action.' });
    return;
  }
  req.user = user;
  next();
}

function haversineMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function generateComplaintId(): string {
  dbState.sequenceCounter += 1;
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, '0');
  const d = String(now.getUTCDate()).padStart(2, '0');
  const seq = String(dbState.sequenceCounter).padStart(4, '0');
  return `CG-${y}${m}${d}-${seq}`;
}

function computeAnalytics(complaints: Complaint[]): AnalyticsSummary {
  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === 'Resolved').length;
  const active = total - resolved;
  const submittedCount = complaints.filter((c) => c.status === 'Submitted').length;

  const byCategory = VALID_CATEGORIES.map((category) => ({
    category,
    count: complaints.filter((c) => c.category === category).length,
  }));

  const byStatus = VALID_STATUSES.map((status) => ({
    status,
    count: complaints.filter((c) => c.status === status).length,
  }));

  const byPriority = VALID_PRIORITIES.map((priority) => ({
    priority,
    count: complaints.filter((c) => c.priority === priority).length,
  }));

  const areaMap = new Map<string, { area: string; total: number; resolved: number; active: number }>();
  for (const c of complaints) {
    const areaName = c.area.trim() || 'Unspecified Ward';
    const current = areaMap.get(areaName) ?? { area: areaName, total: 0, resolved: 0, active: 0 };
    current.total += 1;
    if (c.status === 'Resolved') {
      current.resolved += 1;
    } else {
      current.active += 1;
    }
    areaMap.set(areaName, current);
  }

  const byArea = Array.from(areaMap.values()).sort((a, b) => b.total - a.total);

  return {
    total,
    resolved,
    active,
    submittedCount,
    byCategory,
    byStatus,
    byPriority,
    byArea,
  };
}

function sanitizeComplaintPublic(c: Complaint): Complaint {
  return {
    ...c,
    upvotedBy: [...c.upvotedBy],
    statusHistory: [...c.statusHistory],
  };
}

function isSafePhotoUrl(url: string): boolean {
  if (url.startsWith('/uploads/') && /^\/uploads\/[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/.test(url)) {
    return true;
  }
  if (
    url.startsWith('/src/assets/images/') &&
    /^\/src\/assets\/images\/[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/.test(url)
  ) {
    return true;
  }
  return false;
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '8mb' }));

  // Safely serve uploaded evidence images with path confinement
  app.get('/uploads/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!/^[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/.test(filename)) {
      res.status(400).json({ error: 'Invalid file name.' });
      return;
    }
    const resolvedPath = path.resolve(UPLOADS_DIR, filename);
    if (!resolvedPath.startsWith(UPLOADS_DIR + path.sep)) {
      res.status(403).json({ error: 'Access denied.' });
      return;
    }
    if (!fs.existsSync(resolvedPath)) {
      res.status(404).json({ error: 'Image not found.' });
      return;
    }
    res.sendFile(resolvedPath);
  });

  // Live SSE feed
  app.get('/api/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);
    sseClients.add(res);
    req.on('close', () => {
      sseClients.delete(res);
    });
  });

  // Auth status and session check
  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = extractBearerUser(req);
    res.json({ user });
  });

  app.get('/api/auth/admin-status', (_req: Request, res: Response) => {
    const envPasscode = process.env.ADMIN_PASSCODE?.trim();
    if (envPasscode) {
      res.json({ configured: true, source: 'env' });
      return;
    }
    if (dbState.adminCredentialHash) {
      res.json({ configured: true, source: 'claimed' });
      return;
    }
    res.json({ configured: false, source: 'unclaimed' });
  });

  app.post('/api/auth/register', (req: Request, res: Response) => {
    const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (name.length < 2 || name.length > 80) {
      res.status(400).json({ error: 'Please enter your full name (2-80 characters).' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (password.length < 6 || password.length > 128) {
      res.status(400).json({ error: 'Password must be between 6 and 128 characters.' });
      return;
    }

    const existing = dbState.users.find((u) => u.email === email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const uid = `citizen-${crypto.randomUUID()}`;
    const newUser: StoredUser = {
      uid,
      name,
      email,
      passwordHash: hashPassword(password),
      role: 'citizen',
      createdAt: new Date().toISOString(),
    };
    dbState.users.push(newUser);
    saveDatabase(dbState);

    const authUser: AuthUser = {
      uid: newUser.uid,
      name: newUser.name,
      email: newUser.email,
      role: 'citizen',
    };
    const token = signToken(authUser);
    res.status(201).json({ user: authUser, token });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const found = dbState.users.find((u) => u.email === email);
    if (!found || !verifyPassword(password, found.passwordHash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const authUser: AuthUser = {
      uid: found.uid,
      name: found.name,
      email: found.email,
      role: found.role,
    };
    const token = signToken(authUser);
    res.json({ user: authUser, token });
  });

  // One-time admin password claim when ADMIN_PASSCODE env is not configured
  app.post('/api/auth/admin-claim', (req: Request, res: Response) => {
    const envPasscode = process.env.ADMIN_PASSCODE?.trim();
    if (envPasscode || dbState.adminCredentialHash) {
      res.status(409).json({ error: 'Admin access is already configured. Please sign in.' });
      return;
    }
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const name = typeof req.body?.name === 'string' ? req.body.name.trim() : 'Municipal Admin';
    if (password.length < 8 || password.length > 128) {
      res.status(400).json({ error: 'Admin password must be at least 8 characters long.' });
      return;
    }

    dbState.adminCredentialHash = hashPassword(password);
    saveDatabase(dbState);

    const adminUser: AuthUser = {
      uid: 'admin-primary',
      name: name.slice(0, 60) || 'Municipal Admin',
      email: 'admin@civicgrid.local',
      role: 'admin',
    };
    const token = signToken(adminUser);
    res.status(201).json({ user: adminUser, token });
  });

  app.post('/api/auth/admin-login', (req: Request, res: Response) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!password) {
      res.status(400).json({ error: 'Admin password is required.' });
      return;
    }

    const envPasscode = process.env.ADMIN_PASSCODE?.trim();
    let verified = false;
    if (envPasscode) {
      verified = safeCompareString(password, envPasscode);
    } else if (dbState.adminCredentialHash) {
      verified = verifyPassword(password, dbState.adminCredentialHash);
    } else {
      res.status(400).json({ error: 'Admin password has not been initialized yet.' });
      return;
    }

    if (!verified) {
      res.status(401).json({ error: 'Invalid administrator password.' });
      return;
    }

    const adminUser: AuthUser = {
      uid: 'admin-primary',
      name: 'Municipal Administrator',
      email: 'admin@civicgrid.local',
      role: 'admin',
    };
    const token = signToken(adminUser);
    res.json({ user: adminUser, token });
  });

  // Upload photographic evidence
  app.post('/api/uploads', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
    const match = /^data:(image\/(jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
    if (!match) {
      res.status(400).json({ error: 'Please upload a valid JPEG, PNG, or WebP image.' });
      return;
    }

    const subtype = match[2] === 'jpg' ? 'jpeg' : match[2];
    const base64Data = match[3];
    const buffer = Buffer.from(base64Data, 'base64');

    if (buffer.length === 0 || buffer.length > 5 * 1024 * 1024) {
      res.status(400).json({ error: 'Image file size must be under 5 MB.' });
      return;
    }

    const ext = subtype === 'jpeg' ? 'jpg' : subtype;
    const filename = `evidence_${Date.now()}_${crypto.randomBytes(8).toString('hex')}.${ext}`;
    const resolvedPath = path.resolve(UPLOADS_DIR, filename);
    if (!resolvedPath.startsWith(UPLOADS_DIR + path.sep)) {
      res.status(403).json({ error: 'Invalid upload destination.' });
      return;
    }

    fs.writeFileSync(resolvedPath, buffer);
    res.status(201).json({ photoURL: `/uploads/${filename}` });
  });

  // Public complaints list + analytics
  app.get('/api/complaints', (req: Request, res: Response) => {
    const category = typeof req.query.category === 'string' ? req.query.category : '';
    const status = typeof req.query.status === 'string' ? req.query.status : '';
    const mine = req.query.mine === 'true';
    const user = extractBearerUser(req);

    let items = dbState.complaints;
    if (category && VALID_CATEGORIES.includes(category as IssueCategory)) {
      items = items.filter((c) => c.category === category);
    }
    if (status && VALID_STATUSES.includes(status as ComplaintStatus)) {
      items = items.filter((c) => c.status === status);
    }
    if (mine) {
      if (!user) {
        res.status(401).json({ error: 'Sign in to view your submitted complaints.' });
        return;
      }
      items = items.filter((c) => c.userId === user.uid);
    }

    const sorted = [...items].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    res.json({
      complaints: sorted.map(sanitizeComplaintPublic),
      analytics: computeAnalytics(dbState.complaints),
    });
  });

  // Nearby duplicate check (within 300 meters)
  app.get('/api/complaints/nearby', (req: Request, res: Response) => {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);
    const category = typeof req.query.category === 'string' ? req.query.category : '';

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      res.status(400).json({ error: 'Valid latitude and longitude are required.' });
      return;
    }

    const nearby = dbState.complaints
      .filter((c) => c.status !== 'Resolved')
      .filter((c) => !category || c.category === category)
      .map((c) => ({
        complaint: sanitizeComplaintPublic(c),
        distanceMeters: Math.round(haversineMeters(lat, lng, c.latitude, c.longitude)),
      }))
      .filter((entry) => entry.distanceMeters <= 300)
      .sort((a, b) => a.distanceMeters - b.distanceMeters);

    res.json({ nearby });
  });

  // Lookup single complaint by unique ID
  app.get('/api/complaints/:id', (req: Request, res: Response) => {
    const id = String(req.params.id || '').trim().toUpperCase();
    if (!id || id.length > 40) {
      res.status(400).json({ error: 'Please enter a valid complaint ID.' });
      return;
    }
    const found = dbState.complaints.find((c) => c.complaintId.toUpperCase() === id);
    if (!found) {
      res.status(404).json({ error: `No complaint found with ID "${id}".` });
      return;
    }
    res.json({ complaint: sanitizeComplaintPublic(found) });
  });

  // Create new complaint
  app.post('/api/complaints', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = req.user!;
    const category = req.body?.category;
    const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
    const area = typeof req.body?.area === 'string' ? req.body.area.trim() : '';
    const photoURL = typeof req.body?.photoURL === 'string' ? req.body.photoURL.trim() : '';
    const latitude = Number(req.body?.latitude);
    const longitude = Number(req.body?.longitude);
    const priority = VALID_PRIORITIES.includes(req.body?.priority) ? req.body.priority : 'Medium';
    const aiClassified = Boolean(req.body?.aiClassified);

    if (!VALID_CATEGORIES.includes(category)) {
      res.status(400).json({ error: 'Please select a valid civic issue category.' });
      return;
    }
    if (description.length < 10 || description.length > 1000) {
      res.status(400).json({ error: 'Description must be between 10 and 1000 characters.' });
      return;
    }
    if (area.length < 2 || area.length > 120) {
      res.status(400).json({ error: 'Please enter the neighborhood, street, or ward name.' });
      return;
    }
    if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
      res.status(400).json({ error: 'Valid latitude coordinate is required.' });
      return;
    }
    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
      res.status(400).json({ error: 'Valid longitude coordinate is required.' });
      return;
    }
    if (!photoURL || !isSafePhotoUrl(photoURL)) {
      res.status(400).json({ error: 'Please upload a valid photograph of the civic issue.' });
      return;
    }

    const now = new Date().toISOString();
    const complaintId = generateComplaintId();

    const newComplaint: Complaint = {
      complaintId,
      category,
      description,
      area,
      photoURL,
      latitude: Number(latitude.toFixed(6)),
      longitude: Number(longitude.toFixed(6)),
      status: 'Submitted',
      priority,
      userId: user.uid,
      reporterName: user.name,
      upvotes: 1,
      upvotedBy: [user.uid],
      aiClassified,
      createdAt: now,
      updatedAt: now,
      statusHistory: [
        {
          status: 'Submitted',
          note: 'Complaint received with location pin and photographic evidence.',
          updatedAt: now,
          updatedBy: user.name,
        },
      ],
    };

    dbState.complaints.unshift(newComplaint);
    saveDatabase(dbState);
    broadcastEvent('complaint_created', sanitizeComplaintPublic(newComplaint));

    res.status(201).json({ complaint: sanitizeComplaintPublic(newComplaint) });
  });

  // Upvote/endorse an existing open complaint (helps prioritize duplicates)
  app.post('/api/complaints/:id/upvote', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = req.user!;
    const id = String(req.params.id || '').trim().toUpperCase();
    const found = dbState.complaints.find((c) => c.complaintId.toUpperCase() === id);
    if (!found) {
      res.status(404).json({ error: 'Complaint not found.' });
      return;
    }
    if (found.upvotedBy.includes(user.uid)) {
      res.json({ complaint: sanitizeComplaintPublic(found), alreadyUpvoted: true });
      return;
    }
    found.upvotedBy.push(user.uid);
    found.upvotes = found.upvotedBy.length;
    found.updatedAt = new Date().toISOString();
    saveDatabase(dbState);
    broadcastEvent('complaint_updated', sanitizeComplaintPublic(found));
    res.json({ complaint: sanitizeComplaintPublic(found), alreadyUpvoted: false });
  });

  // Admin: update status, priority, department assignment, and resolution notes
  app.patch('/api/complaints/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const admin = req.user!;
    const id = String(req.params.id || '').trim().toUpperCase();
    const found = dbState.complaints.find((c) => c.complaintId.toUpperCase() === id);
    if (!found) {
      res.status(404).json({ error: 'Complaint not found.' });
      return;
    }

    const nextStatus = req.body?.status;
    const nextPriority = req.body?.priority;
    const assignedDepartment =
      typeof req.body?.assignedDepartment === 'string'
        ? req.body.assignedDepartment.trim().slice(0, 100)
        : undefined;
    const adminNotes =
      typeof req.body?.adminNotes === 'string'
        ? req.body.adminNotes.trim().slice(0, 400)
        : undefined;

    if (nextStatus !== undefined && !VALID_STATUSES.includes(nextStatus)) {
      res.status(400).json({ error: 'Invalid status value.' });
      return;
    }
    if (nextPriority !== undefined && !VALID_PRIORITIES.includes(nextPriority)) {
      res.status(400).json({ error: 'Invalid priority value.' });
      return;
    }

    const now = new Date().toISOString();
    const statusChanged = nextStatus !== undefined && nextStatus !== found.status;

    if (nextStatus !== undefined) found.status = nextStatus;
    if (nextPriority !== undefined) found.priority = nextPriority;
    if (assignedDepartment !== undefined) found.assignedDepartment = assignedDepartment;
    if (adminNotes !== undefined) found.adminNotes = adminNotes;
    found.updatedAt = now;

    if (statusChanged || adminNotes) {
      const historyNote =
        adminNotes && adminNotes.length > 0
          ? adminNotes
          : `Status updated to ${found.status}${found.assignedDepartment ? ` (${found.assignedDepartment})` : ''}.`;
      found.statusHistory.push({
        status: found.status,
        note: historyNote,
        updatedAt: now,
        updatedBy: admin.name,
      });
    }

    saveDatabase(dbState);
    broadcastEvent('complaint_updated', sanitizeComplaintPublic(found));
    res.json({ complaint: sanitizeComplaintPublic(found) });
  });

  // Server-side Gemini AI image & text classification + priority detection
  app.post('/api/ai/analyze', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
    const apiKey = process.env.GEMINI_API_KEY?.trim();
    if (!apiKey) {
      res.status(503).json({
        error:
          'GEMINI_API_KEY is not configured in Settings > Secrets. You can still select category and priority manually.',
      });
      return;
    }

    const imageDataUrl = typeof req.body?.imageDataUrl === 'string' ? req.body.imageDataUrl : '';
    const descriptionHint =
      typeof req.body?.description === 'string' ? req.body.description.trim().slice(0, 600) : '';

    if (!imageDataUrl && !descriptionHint) {
      res.status(400).json({
        error: 'Please upload a photo or enter a short description before running AI analysis.',
      });
      return;
    }

    const parts: Array<{ inlineData: { mimeType: string; data: string } } | { text: string }> = [];
    if (imageDataUrl) {
      const match = /^data:(image\/(jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(
        imageDataUrl
      );
      if (!match) {
        res.status(400).json({ error: 'Invalid image data format for AI classification.' });
        return;
      }
      parts.push({
        inlineData: {
          mimeType: match[1] === 'image/jpg' ? 'image/jpeg' : match[1],
          data: match[3],
        },
      });
    }

    parts.push({
      text: `You are a municipal civic infrastructure triage classifier for CivicGrid.
Analyze the provided civic issue photo and/or citizen note and classify it into exactly one category:
- "Pothole" (localized road cavity/pavement hole)
- "Garbage" (uncollected waste piles, dumped trash bags on street/sidewalk)
- "Damaged Road" (broader road surface collapse, cracked tarmac, broken curb/shoulder)
- "Streetlight" (broken, leaning, unlit, or flickering municipal streetlight)
- "Dustbin" (overflowing or damaged public street litter bin)

Assess urgency priority ("Low", "Medium", "High", or "Critical") based on safety, traffic obstruction, or public health risk.
Write a clear, factual 1-2 sentence suggestedDescription suitable for a municipal work order, and a brief 1-sentence reasoning.
Citizen note: ${descriptionHint || 'No text note provided; rely on the image.'}`,
    });

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              category: {
                type: Type.STRING,
                enum: VALID_CATEGORIES,
                description: 'Classified civic issue category.',
              },
              priority: {
                type: Type.STRING,
                enum: VALID_PRIORITIES,
                description: 'Assessed severity priority.',
              },
              suggestedDescription: {
                type: Type.STRING,
                description: 'Clear 1-2 sentence municipal complaint description.',
              },
              reasoning: {
                type: Type.STRING,
                description: 'Brief 1-sentence explanation for the category and priority.',
              },
            },
            required: ['category', 'priority', 'suggestedDescription', 'reasoning'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as AiIssueAnalysis;
      if (!VALID_CATEGORIES.includes(parsed.category) || !VALID_PRIORITIES.includes(parsed.priority)) {
        res.status(502).json({ error: 'AI returned an unexpected classification format.' });
        return;
      }

      res.json({ analysis: parsed });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'AI analysis failed.';
      res.status(502).json({ error: `AI classification error: ${message}` });
    }
  });

  // Mount Vite middleware in dev, or static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CivicGrid server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start CivicGrid server:', err);
  process.exit(1);
});
