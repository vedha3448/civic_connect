export type IssueCategory =
  | 'Pothole'
  | 'Garbage'
  | 'Damaged Road'
  | 'Streetlight'
  | 'Dustbin';

export type ComplaintStatus =
  | 'Submitted'
  | 'Under Review'
  | 'Assigned'
  | 'In Progress'
  | 'Resolved';

export type IssuePriority = 'Low' | 'Medium' | 'High' | 'Critical';

export type UserRole = 'citizen' | 'admin';

export interface StatusHistoryEntry {
  status: ComplaintStatus;
  note: string;
  updatedAt: string;
  updatedBy: string;
}

export interface Complaint {
  complaintId: string;
  category: IssueCategory;
  description: string;
  area: string;
  photoURL: string;
  latitude: number;
  longitude: number;
  status: ComplaintStatus;
  priority: IssuePriority;
  assignedDepartment?: string;
  adminNotes?: string;
  userId: string;
  reporterName: string;
  upvotes: number;
  upvotedBy: string[];
  aiClassified?: boolean;
  createdAt: string;
  updatedAt: string;
  statusHistory: StatusHistoryEntry[];
}

export interface AuthUser {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface AiIssueAnalysis {
  category: IssueCategory;
  priority: IssuePriority;
  suggestedDescription: string;
  reasoning: string;
}

export interface AnalyticsSummary {
  total: number;
  resolved: number;
  active: number;
  submittedCount: number;
  byCategory: { category: IssueCategory; count: number }[];
  byStatus: { status: ComplaintStatus; count: number }[];
  byPriority: { priority: IssuePriority; count: number }[];
  byArea: { area: string; total: number; resolved: number; active: number }[];
}

export const ISSUE_CATEGORIES: IssueCategory[] = [
  'Pothole',
  'Garbage',
  'Damaged Road',
  'Streetlight',
  'Dustbin',
];

export const COMPLAINT_STATUSES: ComplaintStatus[] = [
  'Submitted',
  'Under Review',
  'Assigned',
  'In Progress',
  'Resolved',
];

export const ISSUE_PRIORITIES: IssuePriority[] = [
  'Low',
  'Medium',
  'High',
  'Critical',
];

export const MUNICIPAL_DEPARTMENTS: string[] = [
  'Road Maintenance Unit',
  'Sanitation & Solid Waste',
  'Electrical & Streetlight Wing',
  'Public Works & Drainage',
  'Ward Inspection Squad',
];
