import type { ComplaintStatus, IssueCategory, IssuePriority } from '../types/civic';

export function getStatusDotColor(status: ComplaintStatus): string {
  switch (status) {
    case 'Submitted':
      return '#64748b';
    case 'Under Review':
      return '#d97706';
    case 'Assigned':
      return '#4f46e5';
    case 'In Progress':
      return '#0284c7';
    case 'Resolved':
      return '#16a34a';
  }
}

export function getStatusTextClass(status: ComplaintStatus): string {
  switch (status) {
    case 'Submitted':
      return 'text-slate-700';
    case 'Under Review':
      return 'text-amber-700';
    case 'Assigned':
      return 'text-indigo-700';
    case 'In Progress':
      return 'text-sky-700';
    case 'Resolved':
      return 'text-emerald-700';
  }
}

export function getPriorityTextClass(priority: IssuePriority): string {
  switch (priority) {
    case 'Low':
      return 'text-slate-600';
    case 'Medium':
      return 'text-sky-700';
    case 'High':
      return 'text-amber-700';
    case 'Critical':
      return 'text-red-700 font-semibold';
  }
}

export function getCategoryDescription(category: IssueCategory): string {
  switch (category) {
    case 'Pothole':
      return 'Localized road cavities, asphalt craters, and pavement hazards.';
    case 'Garbage':
      return 'Uncollected residential waste piles or illegal street dumping.';
    case 'Damaged Road':
      return 'Broken tarmac, collapsed shoulders, and uneven crossings.';
    case 'Streetlight':
      return 'Unlit municipal poles, flickering lamps, or exposed wiring.';
    case 'Dustbin':
      return 'Overflowing or damaged public street waste receptacles.';
  }
}

export function formatShortDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
