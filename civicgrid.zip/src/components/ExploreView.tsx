import { useMemo, useState } from 'react';
import { BarChart3, Map as MapIcon, Search, ThumbsUp } from 'lucide-react';
import type {
  AnalyticsSummary,
  AuthUser,
  Complaint,
  ComplaintStatus,
  IssueCategory,
} from '../types/civic';
import { COMPLAINT_STATUSES, ISSUE_CATEGORIES } from '../types/civic';
import {
  formatShortDate,
  getPriorityTextClass,
  getStatusDotColor,
  getStatusTextClass,
} from '../utils/statusStyles';
import { ExploreLeafletMap } from './LeafletMap';
import { SafeImage } from './SafeImage';

interface ExploreViewProps {
  complaints: Complaint[];
  analytics: AnalyticsSummary | null;
  user: AuthUser | null;
  onTrackId: (complaintId: string) => void;
  onUpvote: (complaintId: string) => Promise<void>;
  onRequireSignIn: () => void;
}

export function ExploreView({
  complaints,
  analytics,
  user,
  onTrackId,
  onUpvote,
  onRequireSignIn,
}: ExploreViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<'All' | IssueCategory>('All');
  const [selectedStatus, setSelectedStatus] = useState<'All' | ComplaintStatus>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(
    complaints[0]?.complaintId ?? null
  );
  const [tab, setTab] = useState<'map' | 'analytics'>('map');
  const [upvotingId, setUpvotingId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return complaints.filter((c) => {
      if (selectedCategory !== 'All' && c.category !== selectedCategory) return false;
      if (selectedStatus !== 'All' && c.status !== selectedStatus) return false;
      if (q) {
        const match =
          c.complaintId.toLowerCase().includes(q) ||
          c.area.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.category.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [complaints, selectedCategory, selectedStatus, searchTerm]);

  const handleUpvoteClick = async (complaintId: string) => {
    if (!user) {
      onRequireSignIn();
      return;
    }
    setUpvotingId(complaintId);
    try {
      await onUpvote(complaintId);
    } finally {
      setUpvotingId(null);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8">
      {/* Page Header & Mode Switch */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Live Public Issue Map
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Real-time OpenStreetMap registry of civic complaints across neighborhood wards.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setTab('map')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'map'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <MapIcon className="w-3.5 h-3.5" />
            Interactive Map
          </button>
          <button
            type="button"
            onClick={() => setTab('analytics')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'analytics'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Area Analytics
          </button>
        </div>
      </div>

      {/* Filters Toolbar */}
      <div className="mt-6 flex flex-col lg:flex-row gap-4 lg:items-center justify-between">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            type="button"
            onClick={() => setSelectedCategory('All')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              selectedCategory === 'All'
                ? 'bg-white text-slate-950 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            All Issues
          </button>
          {ISSUE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat
                  ? 'bg-white text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <select
            aria-label="Filter by status"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as 'All' | ComplaintStatus)}
            className="px-3 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
          >
            <option value="All">All Statuses</option>
            {COMPLAINT_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search ID or ward..."
              className="w-full sm:w-56 pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>
        </div>
      </div>

      {tab === 'map' ? (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* OpenStreetMap Canvas */}
          <div className="lg:col-span-7 space-y-3">
            <ExploreLeafletMap
              complaints={filtered}
              selectedId={selectedId}
              onSelectComplaint={(id) => setSelectedId(id)}
              heightClass="h-[460px] lg:h-[580px]"
            />

            {/* Clean Map Legend */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-600 px-1">
              {COMPLAINT_STATUSES.map((status) => (
                <div key={status} className="inline-flex items-center gap-1.5">
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block"
                    style={{ backgroundColor: getStatusDotColor(status) }}
                    aria-hidden="true"
                  />
                  <span>{status}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Synchronized Issue List */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-950">
                Reported Issues
              </span>
              <span className="font-mono text-xs text-slate-500 tabular-nums">
                {filtered.length} matching
              </span>
            </div>

            {filtered.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-slate-800">
                  No complaints match your current filter.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('All');
                    setSelectedStatus('All');
                    setSearchTerm('');
                  }}
                  className="mt-3 px-4 py-2 text-xs font-semibold text-blue-700 hover:text-blue-800"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-200 max-h-[540px] overflow-y-auto">
                {filtered.map((c) => {
                  const isSelected = c.complaintId === selectedId;
                  const hasUpvoted = user ? c.upvotedBy.includes(user.uid) : false;
                  return (
                    <div
                      key={c.complaintId}
                      onClick={() => setSelectedId(c.complaintId)}
                      className={`p-4 cursor-pointer transition-colors duration-150 ${
                        isSelected ? 'bg-blue-50/60' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex gap-3.5 items-start">
                        <div className="w-20 h-16 rounded-md overflow-hidden shrink-0 border border-slate-200">
                          <SafeImage
                            src={c.photoURL}
                            alt={`${c.category} in ${c.area}`}
                            className="w-full h-full object-cover"
                            fallbackLabel={c.category}
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                            <span className="font-mono font-medium text-slate-700 tabular-nums">
                              {c.complaintId}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{c.category}</span>
                            <span aria-hidden="true">·</span>
                            <span className={`font-semibold ${getStatusTextClass(c.status)}`}>
                              {c.status}
                            </span>
                          </div>

                          <h3 className="mt-1 text-sm font-semibold text-slate-950 truncate">
                            {c.area}
                          </h3>
                          <p className="mt-0.5 text-xs text-slate-600 line-clamp-2">
                            {c.description}
                          </p>

                          <div className="mt-2.5 flex items-center justify-between gap-2 text-xs">
                            <div className="flex items-center gap-2 text-slate-500">
                              <span className={getPriorityTextClass(c.priority)}>
                                {c.priority} priority
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>{formatShortDate(c.createdAt)}</span>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                disabled={upvotingId === c.complaintId || hasUpvoted}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  void handleUpvoteClick(c.complaintId);
                                }}
                                className={`inline-flex items-center gap-1 px-2 py-1 rounded border text-xs font-medium tabular-nums transition-colors ${
                                  hasUpvoted
                                    ? 'border-blue-200 bg-blue-50 text-blue-700'
                                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
                                }`}
                                title="Endorse this issue to indicate community impact"
                              >
                                <ThumbsUp className="w-3 h-3" />
                                <span>{c.upvotes}</span>
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onTrackId(c.complaintId);
                                }}
                                className="px-2.5 py-1 rounded border border-slate-300 bg-white text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap"
                              >
                                Details
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Area-wise Analytics Panel */
        <div className="mt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <h2 className="font-display text-lg font-bold text-slate-950">
                Issues by Category
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Distribution across the five municipal infrastructure categories.
              </p>
              <div className="mt-5 space-y-3.5">
                {(analytics?.byCategory ?? []).map((row) => {
                  const pct =
                    analytics && analytics.total > 0
                      ? Math.round((row.count / analytics.total) * 100)
                      : 0;
                  return (
                    <div key={row.category}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium text-slate-800">{row.category}</span>
                        <span className="font-mono text-slate-600 tabular-nums">
                          {row.count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-700 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <h2 className="font-display text-lg font-bold text-slate-950">
                Resolution Pipeline Status
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Current progression across all five complaint lifecycle stages.
              </p>
              <div className="mt-5 space-y-3.5">
                {(analytics?.byStatus ?? []).map((row) => {
                  const pct =
                    analytics && analytics.total > 0
                      ? Math.round((row.count / analytics.total) * 100)
                      : 0;
                  return (
                    <div key={row.status}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className={`font-medium ${getStatusTextClass(row.status)}`}>
                          {row.status}
                        </span>
                        <span className="font-mono text-slate-600 tabular-nums">
                          {row.count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: getStatusDotColor(row.status),
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Area / Ward Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h2 className="font-display text-lg font-bold text-slate-950">
                Area-Wise Complaint Breakdown
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-6">Ward / Neighborhood</th>
                    <th className="py-3 px-4 text-right">Total Reports</th>
                    <th className="py-3 px-4 text-right">Active</th>
                    <th className="py-3 px-4 text-right">Resolved</th>
                    <th className="py-3 px-6 text-right">Resolution Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {(analytics?.byArea ?? []).map((areaRow) => {
                    const rate =
                      areaRow.total > 0
                        ? Math.round((areaRow.resolved / areaRow.total) * 100)
                        : 0;
                    return (
                      <tr key={areaRow.area} className="hover:bg-slate-50">
                        <td className="py-3 px-6 font-medium text-slate-900">
                          {areaRow.area}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                          {areaRow.total}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-blue-700">
                          {areaRow.active}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                          {areaRow.resolved}
                        </td>
                        <td className="py-3 px-6 text-right font-mono tabular-nums text-slate-800">
                          {rate}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
