import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Search } from 'lucide-react';
import type {
  AnalyticsSummary,
  AuthUser,
  Complaint,
  ComplaintStatus,
  IssueCategory,
  IssuePriority,
} from '../types/civic';
import {
  COMPLAINT_STATUSES,
  ISSUE_CATEGORIES,
  ISSUE_PRIORITIES,
  MUNICIPAL_DEPARTMENTS,
} from '../types/civic';
import {
  formatShortDate,
  getPriorityTextClass,
  getStatusTextClass,
} from '../utils/statusStyles';
import { AuthView } from './AuthView';
import { LocationPickerLeafletMap } from './LeafletMap';
import { SafeImage } from './SafeImage';

interface AdminViewProps {
  user: AuthUser | null;
  token: string | null;
  complaints: Complaint[];
  analytics: AnalyticsSummary | null;
  onAuthenticated: (user: AuthUser, token: string) => void;
  onComplaintUpdated: (complaint: Complaint) => void;
  onBackHome: () => void;
}

export function AdminView({
  user,
  token,
  complaints,
  analytics,
  onAuthenticated,
  onComplaintUpdated,
  onBackHome,
}: AdminViewProps) {
  const [statusFilter, setStatusFilter] = useState<'All' | ComplaintStatus>('All');
  const [categoryFilter, setCategoryFilter] = useState<'All' | IssueCategory>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(
    complaints[0]?.complaintId ?? null
  );

  // Inspector form state
  const [editStatus, setEditStatus] = useState<ComplaintStatus>('Submitted');
  const [editPriority, setEditPriority] = useState<IssuePriority>('Medium');
  const [editDepartment, setEditDepartment] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return complaints.filter((c) => {
      if (statusFilter !== 'All' && c.status !== statusFilter) return false;
      if (categoryFilter !== 'All' && c.category !== categoryFilter) return false;
      if (q) {
        const hit =
          c.complaintId.toLowerCase().includes(q) ||
          c.area.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.reporterName.toLowerCase().includes(q);
        if (!hit) return false;
      }
      return true;
    });
  }, [complaints, statusFilter, categoryFilter, searchTerm]);

  const selectedComplaint =
    complaints.find((c) => c.complaintId === selectedId) ?? filtered[0] ?? null;

  useEffect(() => {
    if (!selectedComplaint) return;
    setEditStatus(selectedComplaint.status);
    setEditPriority(selectedComplaint.priority);
    setEditDepartment(selectedComplaint.assignedDepartment || '');
    setEditNotes(selectedComplaint.adminNotes || '');
    setSaveMessage(null);
    setSaveError(null);
  }, [selectedComplaint?.complaintId]);

  if (!user || user.role !== 'admin' || !token) {
    return (
      <AuthView
        initialMode="admin"
        onAuthenticated={onAuthenticated}
        onBackHome={onBackHome}
      />
    );
  }

  const handleSaveUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedComplaint) return;
    setSaving(true);
    setSaveMessage(null);
    setSaveError(null);

    try {
      const res = await fetch(
        `/api/complaints/${encodeURIComponent(selectedComplaint.complaintId)}`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            status: editStatus,
            priority: editPriority,
            assignedDepartment: editDepartment || undefined,
            adminNotes: editNotes.trim() || undefined,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setSaveError(data.error || 'Failed to update complaint.');
        return;
      }
      onComplaintUpdated(data.complaint as Complaint);
      setSaveMessage('Complaint updated and broadcast to public dashboard.');
    } catch {
      setSaveError('Network error while saving update.');
    } finally {
      setSaving(false);
    }
  };

  const total = analytics?.total ?? complaints.length;
  const pendingReview = complaints.filter(
    (c) => c.status === 'Submitted' || c.status === 'Under Review'
  ).length;
  const activeWork = complaints.filter(
    (c) => c.status === 'Assigned' || c.status === 'In Progress'
  ).length;
  const resolved = analytics?.resolved ?? complaints.filter((c) => c.status === 'Resolved').length;

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-8">
      <div className="pb-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
            Municipal Admin Console
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Review incoming citizen complaints, assign field departments, and update resolution
            status.
          </p>
        </div>
        <div className="text-xs text-slate-600">
          Signed in as <span className="font-semibold text-slate-900">{user.name}</span>
        </div>
      </div>

      {/* 4 KPI Summary Strip */}
      <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Total Reports</div>
          <div className="mt-1 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {total}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Awaiting Triage</div>
          <div className="mt-1 font-mono text-2xl font-bold text-amber-700 tabular-nums">
            {pendingReview}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Assigned / In Progress</div>
          <div className="mt-1 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {activeWork}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Resolved</div>
          <div className="mt-1 font-mono text-2xl font-bold text-emerald-700 tabular-nums">
            {resolved}
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="mt-6 flex flex-col lg:flex-row gap-3 lg:items-center justify-between">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            type="button"
            onClick={() => setStatusFilter('All')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              statusFilter === 'All'
                ? 'bg-white text-slate-950 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            All Statuses
          </button>
          {COMPLAINT_STATUSES.map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-white text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <select
            aria-label="Filter by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as 'All' | IssueCategory)}
            className="px-3 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
          >
            <option value="All">All Categories</option>
            {ISSUE_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search ID, ward, reporter..."
              className="w-full sm:w-60 pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>
        </div>
      </div>

      {/* Main Split: Complaints Table + Side Action Inspector */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Complaint ID</th>
                  <th className="py-3 px-4">Issue & Area</th>
                  <th className="py-3 px-3">Priority</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-4 text-right">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-sm text-slate-500">
                      No complaints match the selected filters.
                    </td>
                  </tr>
                ) : (
                  filtered.map((c) => {
                    const isSelected = selectedComplaint?.complaintId === c.complaintId;
                    return (
                      <tr
                        key={c.complaintId}
                        onClick={() => setSelectedId(c.complaintId)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900 whitespace-nowrap tabular-nums">
                          {c.complaintId}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-950">{c.area}</div>
                          <div className="text-xs text-slate-500">
                            {c.category} · {c.assignedDepartment || 'Unassigned'}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-xs whitespace-nowrap">
                          <span className={getPriorityTextClass(c.priority)}>{c.priority}</span>
                        </td>
                        <td className="py-3 px-3 text-xs font-semibold whitespace-nowrap">
                          <span className={getStatusTextClass(c.status)}>{c.status}</span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs text-slate-500 whitespace-nowrap tabular-nums">
                          {formatShortDate(c.createdAt)}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Side Inspector & Update Panel */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6">
          {!selectedComplaint ? (
            <div className="py-12 text-center text-sm text-slate-500">
              Select a complaint row to inspect evidence and update its status.
            </div>
          ) : (
            <form onSubmit={handleSaveUpdate} className="space-y-5">
              <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-200">
                <div>
                  <div className="font-mono text-xs font-semibold text-blue-700">
                    {selectedComplaint.complaintId}
                  </div>
                  <h2 className="mt-0.5 font-display text-lg font-bold text-slate-950">
                    {selectedComplaint.category} · {selectedComplaint.area}
                  </h2>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Reported by {selectedComplaint.reporterName} · {selectedComplaint.upvotes}{' '}
                    endorsements
                  </div>
                </div>
              </div>

              <div className="h-44 rounded-lg overflow-hidden border border-slate-200">
                <SafeImage
                  src={selectedComplaint.photoURL}
                  alt={`${selectedComplaint.category} evidence`}
                  className="w-full h-full object-cover"
                  fallbackLabel={selectedComplaint.category}
                />
              </div>

              <p className="text-sm text-slate-700 leading-relaxed">
                {selectedComplaint.description}
              </p>

              <LocationPickerLeafletMap
                latitude={selectedComplaint.latitude}
                longitude={selectedComplaint.longitude}
                onChangeLocation={() => {}}
                interactive={false}
                heightClass="h-44"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label
                    htmlFor="admin-status"
                    className="block text-xs font-semibold text-slate-800 mb-1"
                  >
                    Complaint Status
                  </label>
                  <select
                    id="admin-status"
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as ComplaintStatus)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  >
                    {COMPLAINT_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="admin-priority"
                    className="block text-xs font-semibold text-slate-800 mb-1"
                  >
                    Priority Level
                  </label>
                  <select
                    id="admin-priority"
                    value={editPriority}
                    onChange={(e) => setEditPriority(e.target.value as IssuePriority)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  >
                    {ISSUE_PRIORITIES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="admin-dept"
                  className="block text-xs font-semibold text-slate-800 mb-1"
                >
                  Assign Municipal Department / Crew
                </label>
                <select
                  id="admin-dept"
                  value={editDepartment}
                  onChange={(e) => setEditDepartment(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                >
                  <option value="">Unassigned</option>
                  {MUNICIPAL_DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="admin-notes"
                  className="block text-xs font-semibold text-slate-800 mb-1"
                >
                  Official Inspection / Resolution Note
                </label>
                <textarea
                  id="admin-notes"
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Enter field inspection remarks or resolution summary..."
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>

              {saveError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
                  {saveError}
                </div>
              )}

              {saveMessage && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-medium">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{saveMessage}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={saving}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
              >
                {saving ? 'Saving Update...' : 'Save Status & Assignment'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
