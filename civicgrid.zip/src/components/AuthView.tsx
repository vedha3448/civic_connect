import { useEffect, useState } from 'react';
import { Lock, Shield, UserCheck } from 'lucide-react';
import type { AuthUser } from '../types/civic';

interface AuthViewProps {
  onAuthenticated: (user: AuthUser, token: string) => void;
  initialMode?: 'citizen-login' | 'citizen-register' | 'admin';
  onBackHome: () => void;
}

export function AuthView({
  onAuthenticated,
  initialMode = 'citizen-login',
  onBackHome,
}: AuthViewProps) {
  const [mode, setMode] = useState<'citizen-login' | 'citizen-register' | 'admin'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [adminStatus, setAdminStatus] = useState<{
    configured: boolean;
    source: 'env' | 'claimed' | 'unclaimed';
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  useEffect(() => {
    let active = true;
    fetch('/api/auth/admin-status')
      .then((res) => res.json())
      .then((data) => {
        if (active) setAdminStatus(data);
      })
      .catch(() => {
        if (active) setAdminStatus({ configured: false, source: 'unclaimed' });
      });
    return () => {
      active = false;
    };
  }, []);

  const handleCitizenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const endpoint = mode === 'citizen-register' ? '/api/auth/register' : '/api/auth/login';
      const payload =
        mode === 'citizen-register' ? { name, email, password } : { email, password };
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Authentication failed.');
        return;
      }
      onAuthenticated(data.user, data.token);
    } catch {
      setError('Unable to reach server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const isUnclaimed = adminStatus && !adminStatus.configured;
      const endpoint = isUnclaimed ? '/api/auth/admin-claim' : '/api/auth/admin-login';
      const payload = isUnclaimed ? { name: name || 'Municipal Admin', password } : { password };
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Administrator authentication failed.');
        return;
      }
      onAuthenticated(data.user, data.token);
    } catch {
      setError('Unable to reach server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[540px] mx-auto px-4 sm:px-6 py-12">
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="flex items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-950">
              {mode === 'admin'
                ? adminStatus && !adminStatus.configured
                  ? 'Initialize Admin Access'
                  : 'Municipal Admin Sign In'
                : mode === 'citizen-register'
                ? 'Create Citizen Account'
                : 'Citizen Sign In'}
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              {mode === 'admin'
                ? 'Authorized portal for reviewing, assigning, and resolving civic complaints.'
                : 'Sign in to submit geo-tagged civic reports and endorse neighborhood issues.'}
            </p>
          </div>
        </div>

        {/* Segmented mode selector */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg mb-6">
          <button
            type="button"
            onClick={() => {
              setMode('citizen-login');
              setError(null);
            }}
            className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              mode === 'citizen-login'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            Citizen Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('citizen-register');
              setError(null);
            }}
            className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              mode === 'citizen-register'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            Register
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('admin');
              setError(null);
            }}
            className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              mode === 'admin'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            Admin Console
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
            {error}
          </div>
        )}

        {mode === 'admin' ? (
          <form onSubmit={handleAdminSubmit} className="space-y-4">
            {adminStatus && !adminStatus.configured && (
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                <div className="flex items-center gap-1.5 font-semibold text-slate-900 mb-1">
                  <Shield className="w-4 h-4 text-blue-700" />
                  First-Run Admin Setup
                </div>
                No administrator password has been claimed yet. Choose a strong password (minimum 8
                characters) to initialize the municipal Admin Dashboard.
              </div>
            )}

            {adminStatus && !adminStatus.configured && (
              <div>
                <label htmlFor="admin-name" className="block text-sm font-medium text-slate-800 mb-1.5">
                  Administrator Name
                </label>
                <input
                  id="admin-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ward Engineer"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>
            )}

            <div>
              <label htmlFor="admin-pass" className="block text-sm font-medium text-slate-800 mb-1.5">
                Administrator Password
              </label>
              <input
                id="admin-pass"
                type="password"
                required
                minLength={adminStatus && !adminStatus.configured ? 8 : 1}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={
                  adminStatus && !adminStatus.configured
                    ? 'Create admin password (min 8 chars)'
                    : 'Enter administrator password'
                }
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
            >
              <Lock className="w-4 h-4" />
              {loading
                ? 'Verifying...'
                : adminStatus && !adminStatus.configured
                ? 'Set Admin Password & Enter Dashboard'
                : 'Sign In as Administrator'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleCitizenSubmit} className="space-y-4">
            {mode === 'citizen-register' && (
              <div>
                <label htmlFor="citizen-name" className="block text-sm font-medium text-slate-800 mb-1.5">
                  Full Name
                </label>
                <input
                  id="citizen-name"
                  type="text"
                  required
                  minLength={2}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                />
              </div>
            )}

            <div>
              <label htmlFor="citizen-email" className="block text-sm font-medium text-slate-800 mb-1.5">
                Email Address
              </label>
              <input
                id="citizen-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="citizen@example.com"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>

            <div>
              <label htmlFor="citizen-password" className="block text-sm font-medium text-slate-800 mb-1.5">
                Password
              </label>
              <input
                id="citizen-password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
            >
              <UserCheck className="w-4 h-4" />
              {loading
                ? 'Please wait...'
                : mode === 'citizen-register'
                ? 'Create Account & Continue'
                : 'Sign In'}
            </button>
          </form>
        )}

        <div className="mt-6 pt-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <button type="button" onClick={onBackHome} className="hover:text-slate-900">
            Return to Home
          </button>
          <span>Role-verified session</span>
        </div>
      </div>
    </div>
  );
}
