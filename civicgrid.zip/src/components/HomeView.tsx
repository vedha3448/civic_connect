import { ArrowRight, MapPin, Search } from 'lucide-react';
import type { AnalyticsSummary, Complaint, IssueCategory } from '../types/civic';
import { ISSUE_CATEGORIES } from '../types/civic';
import { formatShortDate, getCategoryDescription, getStatusTextClass } from '../utils/statusStyles';
import type { ActivePage } from './Navbar';
import { SafeImage } from './SafeImage';

interface HomeViewProps {
  analytics: AnalyticsSummary | null;
  recentComplaints: Complaint[];
  onNavigate: (page: ActivePage) => void;
  onReportCategory: (category: IssueCategory) => void;
  onTrackId: (complaintId: string) => void;
}

export function HomeView({
  analytics,
  recentComplaints,
  onNavigate,
  onReportCategory,
  onTrackId,
}: HomeViewProps) {
  const totalCount = analytics?.total ?? 0;
  const activeCount = analytics?.active ?? 0;
  const resolvedCount = analytics?.resolved ?? 0;
  const wardsCount = analytics?.byArea.length ?? 0;

  return (
    <div className="bg-slate-50">
      {/* Section 1: Hero Split */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="text-sm font-medium text-blue-700 mb-3">
                CivicGrid Municipal Reporting · Report it. Track it. Fix it.
              </p>
              <h1 className="font-display text-[clamp(2.25rem,4vw,3.5rem)] leading-[1.08] font-bold tracking-tight text-slate-950 [text-wrap:balance]">
                Report neighborhood issues and track every fix in public.
              </h1>
              <p className="mt-5 text-base sm:text-lg leading-relaxed text-slate-600 max-w-xl">
                Potholes, uncollected garbage, damaged roads, broken streetlights, and overflowing
                dustbins slow down daily urban life. CivicGrid connects residents directly to
                municipal teams with GPS pins, photo evidence, and verifiable complaint IDs.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('report')}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-700"
                >
                  Report an Issue
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('explore')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
                >
                  <MapPin className="w-4 h-4 text-slate-600" />
                  Explore Public Map
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('track')}
                  className="inline-flex items-center gap-1.5 px-3 py-3 text-sm font-medium text-slate-600 hover:text-slate-950 underline-offset-4 hover:underline whitespace-nowrap shrink-0"
                >
                  <Search className="w-4 h-4" />
                  Track Complaint ID
                </button>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <SafeImage
                  src="/src/assets/images/hero_civic_infrastructure_1795515515169.jpg"
                  alt="Clean city avenue with maintained roads, streetlights, and pedestrian crossings"
                  className="w-full h-full object-cover"
                  fallbackLabel="CivicGrid Urban Infrastructure"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/85 via-slate-950/45 to-transparent p-6">
                  <p className="text-sm font-medium text-white">
                    OpenStreetMap Live Registry · GPS Pinning · Public Accountability
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 4-column Live Civic Accountability Strip below Hero Split */}
          <div className="mt-10 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <div className="text-xs font-medium text-slate-500">Logged Civic Reports</div>
              <div className="mt-1 font-mono text-2xl sm:text-3xl font-semibold text-slate-950 tabular-nums">
                {totalCount}
              </div>
              <div className="mt-0.5 text-xs text-slate-500">Verified in public registry</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Active Resolution Queue</div>
              <div className="mt-1 font-mono text-2xl sm:text-3xl font-semibold text-blue-700 tabular-nums">
                {activeCount}
              </div>
              <div className="mt-0.5 text-xs text-slate-500">Submitted, reviewed, or dispatched</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Resolved Issues</div>
              <div className="mt-1 font-mono text-2xl sm:text-3xl font-semibold text-emerald-700 tabular-nums">
                {resolvedCount}
              </div>
              <div className="mt-0.5 text-xs text-slate-500">Completed with field notes</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Wards & Areas Covered</div>
              <div className="mt-1 font-mono text-2xl sm:text-3xl font-semibold text-slate-950 tabular-nums">
                {wardsCount}
              </div>
              <div className="mt-0.5 text-xs text-slate-500">Live neighborhood coverage</div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: How CivicGrid Works */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 py-14">
        <div className="max-w-2xl">
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950 [text-wrap:balance]">
            Transparent workflow from street observation to verified resolution
          </h2>
          <p className="mt-2 text-base text-slate-600">
            Every report receives a unique complaint identifier and progresses through five
            publicly visible status stages.
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              step: '01. Report with Evidence',
              body: 'Select an issue category, describe the hazard, and attach a clear photograph. Built-in AI assistance can classify photos and assess urgency.',
            },
            {
              step: '02. Pin Exact GPS Location',
              body: 'Capture street coordinates automatically via browser Geolocation or fine-tune the marker manually on an interactive OpenStreetMap canvas.',
            },
            {
              step: '03. Receive Unique Tracking ID',
              body: 'Each submission generates a permanent reference ID such as CG-20261124-0001 and checks nearby active reports to prevent duplicates.',
            },
            {
              step: '04. Review & Resolution',
              body: 'Municipal administrators inspect reports, assign field departments, and update statuses from Submitted through Resolved in real time.',
            },
          ].map((item) => (
            <div
              key={item.step}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between"
            >
              <div>
                <h3 className="font-display text-base font-semibold text-slate-950">
                  {item.step}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-slate-600">{item.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Section 3: Issue Categories & Recent Public Reports */}
      <section className="bg-white border-y border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-14 grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-950">
              Issues handled by CivicGrid
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Choose any category to start a geo-tagged civic complaint with photo proof.
            </p>

            <div className="mt-6 divide-y divide-slate-200 border border-slate-200 rounded-xl bg-slate-50/50">
              {ISSUE_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => onReportCategory(cat)}
                  className="w-full text-left px-5 py-4 hover:bg-white transition-colors duration-150 flex items-center justify-between gap-4 group"
                >
                  <div>
                    <div className="text-sm font-semibold text-slate-900 group-hover:text-blue-700">
                      {cat}
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {getCategoryDescription(cat)}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-2xl font-bold tracking-tight text-slate-950">
                  Recent public submissions
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Live feed of neighborhood reports and their current municipal status.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('explore')}
                className="text-sm font-semibold text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0"
              >
                View all on map
              </button>
            </div>

            <div className="mt-6 space-y-4">
              {recentComplaints.slice(0, 4).map((complaint) => (
                <div
                  key={complaint.complaintId}
                  className="border border-slate-200 rounded-xl p-4 bg-white flex flex-col sm:flex-row gap-4 items-start"
                >
                  <div className="w-full sm:w-32 h-24 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                    <SafeImage
                      src={complaint.photoURL}
                      alt={`${complaint.category} at ${complaint.area}`}
                      className="w-full h-full object-cover"
                      fallbackLabel={complaint.category}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
                      <span className="font-mono font-medium text-slate-700 tabular-nums">
                        {complaint.complaintId}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{complaint.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatShortDate(complaint.createdAt)}</span>
                      <span aria-hidden="true">·</span>
                      <span className={`font-semibold ${getStatusTextClass(complaint.status)}`}>
                        {complaint.status}
                      </span>
                    </div>
                    <h3 className="mt-1 text-base font-semibold text-slate-950 truncate">
                      {complaint.area}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600 line-clamp-2">
                      {complaint.description}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onTrackId(complaint.complaintId)}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0 self-start sm:self-center"
                  >
                    Track Status
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
        <div>
          <span className="font-display font-bold text-slate-900 text-sm">CivicGrid</span>
          <span className="mx-2" aria-hidden="true">·</span>
          <span>Report it. Track it. Fix it.</span>
        </div>
        <div className="flex flex-wrap items-center gap-5">
          <button type="button" onClick={() => onNavigate('explore')} className="hover:text-slate-900">
            Explore Map
          </button>
          <button type="button" onClick={() => onNavigate('report')} className="hover:text-slate-900">
            Report Issue
          </button>
          <button type="button" onClick={() => onNavigate('track')} className="hover:text-slate-900">
            Track Complaint
          </button>
          <button type="button" onClick={() => onNavigate('admin')} className="hover:text-slate-900">
            Admin Console
          </button>
        </div>
      </footer>
    </div>
  );
}
