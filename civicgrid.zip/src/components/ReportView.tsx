import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  Compass,
  Copy,
  Sparkles,
  Upload,
} from 'lucide-react';
import type {
  AiIssueAnalysis,
  AuthUser,
  Complaint,
  IssueCategory,
  IssuePriority,
} from '../types/civic';
import { ISSUE_CATEGORIES, ISSUE_PRIORITIES } from '../types/civic';
import { LocationPickerLeafletMap } from './LeafletMap';
import { getStatusTextClass } from '../utils/statusStyles';

interface ReportViewProps {
  user: AuthUser | null;
  token: string | null;
  initialCategory?: IssueCategory;
  onRequireSignIn: () => void;
  onComplaintCreated: (complaint: Complaint) => void;
  onTrackId: (complaintId: string) => void;
}

interface NearbyMatch {
  complaint: Complaint;
  distanceMeters: number;
}

export function ReportView({
  user,
  token,
  initialCategory = 'Pothole',
  onRequireSignIn,
  onComplaintCreated,
  onTrackId,
}: ReportViewProps) {
  const [category, setCategory] = useState<IssueCategory>(initialCategory);
  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [area, setArea] = useState('');
  const [description, setDescription] = useState('');
  const [latitude, setLatitude] = useState<number>(12.9716);
  const [longitude, setLongitude] = useState<number>(77.5946);
  const [gpsStatus, setGpsStatus] = useState<string | null>(null);

  const [photoPreviewDataUrl, setPhotoPreviewDataUrl] = useState<string>('');
  const [photoFileName, setPhotoFileName] = useState<string>('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<AiIssueAnalysis | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  const [nearbyMatches, setNearbyMatches] = useState<NearbyMatch[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdComplaint, setCreatedComplaint] = useState<Complaint | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    setCategory(initialCategory);
  }, [initialCategory]);

  // Smart duplicate detection near selected coordinates
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    fetch(
      `/api/complaints/nearby?lat=${encodeURIComponent(latitude)}&lng=${encodeURIComponent(
        longitude
      )}&category=${encodeURIComponent(category)}`,
      { signal: controller.signal }
    )
      .then((res) => (res.ok ? res.json() : { nearby: [] }))
      .then((data) => {
        if (active) setNearbyMatches(data.nearby || []);
      })
      .catch(() => {
        // ignore abort errors
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [latitude, longitude, category]);

  const handleDetectGps = () => {
    if (!navigator.geolocation) {
      setGpsStatus('Geolocation is not supported by this browser. Click the map to place a pin.');
      return;
    }
    setGpsStatus('Detecting current GPS coordinates...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(Number(pos.coords.latitude.toFixed(6)));
        setLongitude(Number(pos.coords.longitude.toFixed(6)));
        setGpsStatus('GPS location captured. You can still drag the pin to refine.');
      },
      () => {
        setGpsStatus(
          'Location access denied or unavailable. Please click directly on the map to set the pin.'
        );
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setSubmitError('Please select a JPEG, PNG, or WebP photograph.');
      return;
    }
    if (file.size > 4.5 * 1024 * 1024) {
      setSubmitError('Photograph size must be under 4.5 MB.');
      return;
    }
    setSubmitError(null);
    setPhotoFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoPreviewDataUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAiAnalyze = async () => {
    if (!token) {
      onRequireSignIn();
      return;
    }
    if (!photoPreviewDataUrl && description.trim().length < 5) {
      setAiError('Upload a photograph or type a short note before running AI classification.');
      return;
    }
    setAiError(null);
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          imageDataUrl: photoPreviewDataUrl || undefined,
          description: description.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAiError(data.error || 'AI classification unavailable.');
        return;
      }
      const analysis = data.analysis as AiIssueAnalysis;
      setAiResult(analysis);
      setCategory(analysis.category);
      setPriority(analysis.priority);
      if (description.trim().length < 10 && analysis.suggestedDescription) {
        setDescription(analysis.suggestedDescription);
      }
    } catch {
      setAiError('Unable to reach AI classification service.');
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !user) {
      onRequireSignIn();
      return;
    }
    setSubmitError(null);

    if (!photoPreviewDataUrl) {
      setSubmitError('Please attach a photograph of the civic issue.');
      return;
    }
    if (area.trim().length < 2) {
      setSubmitError('Please enter the street, landmark, or ward name.');
      return;
    }
    if (description.trim().length < 10) {
      setSubmitError('Please provide at least 10 characters describing the issue.');
      return;
    }

    setSubmitting(true);
    try {
      const uploadRes = await fetch('/api/uploads', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ dataUrl: photoPreviewDataUrl }),
      });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) {
        setSubmitError(uploadData.error || 'Failed to upload evidence photograph.');
        return;
      }

      const createRes = await fetch('/api/complaints', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          category,
          priority,
          area: area.trim(),
          description: description.trim(),
          photoURL: uploadData.photoURL,
          latitude,
          longitude,
          aiClassified: Boolean(aiResult),
        }),
      });
      const createData = await createRes.json();
      if (!createRes.ok) {
        setSubmitError(createData.error || 'Failed to submit complaint.');
        return;
      }

      const created = createData.complaint as Complaint;
      setCreatedComplaint(created);
      onComplaintCreated(created);
    } catch {
      setSubmitError('Network error while submitting complaint. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!user || !token) {
    return (
      <div className="max-w-[640px] mx-auto px-4 sm:px-6 py-14">
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
          <h1 className="font-display text-2xl font-bold text-slate-950">
            Sign in to submit a civic complaint
          </h1>
          <p className="mt-2 text-sm text-slate-600 max-w-md mx-auto">
            Citizen verification ensures every report has a valid reporter record and prevents
            spam on the public municipal map.
          </p>
          <button
            type="button"
            onClick={onRequireSignIn}
            className="mt-6 px-6 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
          >
            Sign In or Create Citizen Account
          </button>
        </div>
      </div>
    );
  }

  if (createdComplaint) {
    return (
      <div className="max-w-[680px] mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white border border-slate-200 rounded-xl p-8">
          <div className="flex items-center gap-2.5 text-emerald-700 font-semibold text-sm">
            <CheckCircle2 className="w-5 h-5" />
            Complaint Registered Successfully
          </div>
          <h1 className="mt-3 font-display text-2xl sm:text-3xl font-bold text-slate-950">
            Your Complaint ID is{' '}
            <span className="font-mono text-blue-700">{createdComplaint.complaintId}</span>
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Save this reference ID to check live progress as municipal teams review, assign, and
            resolve the issue.
          </p>

          <div className="mt-6 p-4 rounded-lg bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-xs text-slate-500">Category & Priority</div>
              <div className="font-semibold text-slate-900 mt-0.5">
                {createdComplaint.category} · {createdComplaint.priority}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Current Status</div>
              <div className={`font-semibold mt-0.5 ${getStatusTextClass(createdComplaint.status)}`}>
                {createdComplaint.status}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Ward / Area</div>
              <div className="font-medium text-slate-900 mt-0.5">{createdComplaint.area}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Coordinates</div>
              <div className="font-mono text-xs text-slate-800 mt-1 tabular-nums">
                {createdComplaint.latitude}, {createdComplaint.longitude}
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onTrackId(createdComplaint.complaintId)}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
            >
              Track This Complaint
            </button>
            <button
              type="button"
              onClick={() => {
                void navigator.clipboard?.writeText(createdComplaint.complaintId);
                setCopiedId(true);
                window.setTimeout(() => setCopiedId(false), 2000);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium text-slate-800 border border-slate-300 hover:bg-slate-50 rounded-lg"
            >
              <Copy className="w-4 h-4" />
              {copiedId ? 'Copied ID' : 'Copy ID'}
            </button>
            <button
              type="button"
              onClick={() => {
                setCreatedComplaint(null);
                setArea('');
                setDescription('');
                setPhotoPreviewDataUrl('');
                setPhotoFileName('');
                setAiResult(null);
              }}
              className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-950"
            >
              Submit Another Report
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1160px] mx-auto px-4 sm:px-6 py-8">
      <div className="pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
          Report a Civic Issue
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Attach photographic evidence and pinpoint the location using GPS or the interactive map.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Category, Photo, AI Assistant, Description */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Issue Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {ISSUE_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-3.5 py-2.5 text-xs font-semibold rounded-lg border text-left transition-colors whitespace-nowrap ${
                    category === cat
                      ? 'bg-blue-700 border-blue-700 text-white'
                      : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Photo Evidence Upload */}
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <label className="text-sm font-semibold text-slate-900">
                Photographic Evidence
              </label>
              <button
                type="button"
                onClick={handleAiAnalyze}
                disabled={aiLoading}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {aiLoading ? 'Analyzing...' : 'AI Classify & Priority'}
              </button>
            </div>

            <label className="block cursor-pointer border-2 border-dashed border-slate-300 hover:border-blue-600 rounded-xl bg-white p-5 text-center transition-colors">
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileChange}
                className="sr-only"
              />
              {photoPreviewDataUrl ? (
                <div className="space-y-3">
                  <img
                    src={photoPreviewDataUrl}
                    alt="Uploaded civic issue preview"
                    className="w-full h-52 object-cover rounded-lg border border-slate-200"
                  />
                  <div className="flex items-center justify-center gap-2 text-xs font-medium text-slate-600">
                    <Camera className="w-4 h-4 text-blue-700" />
                    <span>{photoFileName || 'Photo attached'} · Click to replace</span>
                  </div>
                </div>
              ) : (
                <div className="py-4">
                  <Upload className="w-7 h-7 text-slate-400 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-800">
                    Click to upload street photograph
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    JPEG, PNG, or WebP up to 4.5 MB
                  </p>
                </div>
              )}
            </label>

            {aiError && (
              <p className="mt-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
                {aiError}
              </p>
            )}

            {aiResult && (
              <div className="mt-2.5 p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1">
                <div className="font-semibold text-slate-900">
                  AI Triage Suggestion: {aiResult.category} · {aiResult.priority} priority
                </div>
                <p>{aiResult.reasoning}</p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="report-area" className="block text-sm font-semibold text-slate-900 mb-1.5">
                Ward / Street / Landmark
              </label>
              <input
                id="report-area"
                type="text"
                required
                value={area}
                onChange={(e) => setArea(e.target.value)}
                placeholder="e.g. Indiranagar 100ft Road"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>

            <div>
              <label htmlFor="report-priority" className="block text-sm font-semibold text-slate-900 mb-1.5">
                Urgency / Priority
              </label>
              <select
                id="report-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as IssuePriority)}
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              >
                {ISSUE_PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="report-desc" className="block text-sm font-semibold text-slate-900 mb-1.5">
              Problem Description
            </label>
            <textarea
              id="report-desc"
              rows={4}
              required
              minLength={10}
              maxLength={1000}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the exact issue, impact on pedestrians or traffic, and nearby landmarks..."
              className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>
        </div>

        {/* Right Column: GPS + Map Pin + Duplicate Detection + Submit */}
        <div className="lg:col-span-6 space-y-5">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-950">
                  Issue Location (GPS or Manual Map Pin)
                </h2>
                <p className="text-xs text-slate-500">
                  Click anywhere on the map or drag the blue pin to mark the exact spot.
                </p>
              </div>
              <button
                type="button"
                onClick={handleDetectGps}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Compass className="w-3.5 h-3.5 text-blue-700" />
                Use My GPS
              </button>
            </div>

            {gpsStatus && (
              <p className="mb-3 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-md px-3 py-2">
                {gpsStatus}
              </p>
            )}

            <LocationPickerLeafletMap
              latitude={latitude}
              longitude={longitude}
              onChangeLocation={(lat, lng) => {
                setLatitude(lat);
                setLongitude(lng);
              }}
              heightClass="h-80"
            />

            <div className="mt-3 flex items-center justify-between text-xs text-slate-600">
              <span>Selected Coordinates</span>
              <span className="font-mono font-medium text-slate-900 tabular-nums">
                {latitude.toFixed(6)}, {longitude.toFixed(6)}
              </span>
            </div>
          </div>

          {/* Duplicate Detection Alert */}
          {nearbyMatches.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
              <div className="flex items-center gap-2 font-semibold text-sm text-amber-950">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                Possible Duplicate Issue Nearby
              </div>
              <p className="mt-1 text-amber-800">
                {nearbyMatches.length} active {category.toLowerCase()} report(s) already exist
                within 300 meters of this pin. You can inspect an existing report instead or
                continue if this is a separate incident:
              </p>
              <div className="mt-2.5 space-y-1.5">
                {nearbyMatches.slice(0, 2).map((m) => (
                  <div
                    key={m.complaint.complaintId}
                    className="flex items-center justify-between gap-2 bg-white/80 border border-amber-200 rounded-md px-3 py-2"
                  >
                    <div className="min-w-0">
                      <span className="font-mono font-semibold text-slate-900">
                        {m.complaint.complaintId}
                      </span>{' '}
                      · <span className="text-slate-700">{m.complaint.area}</span> ·{' '}
                      <span className="font-mono tabular-nums">{m.distanceMeters}m away</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => onTrackId(m.complaint.complaintId)}
                      className="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap shrink-0"
                    >
                      View Report
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {submitError && (
            <div className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
              {submitError}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 px-6 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
          >
            {submitting ? 'Submitting Complaint...' : 'Submit Civic Complaint'}
          </button>
        </div>
      </form>
    </div>
  );
}
