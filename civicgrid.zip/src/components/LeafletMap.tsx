import { useEffect, useRef } from 'react';
import L from 'leaflet';
import type { Complaint } from '../types/civic';
import { getStatusDotColor } from '../utils/statusStyles';

interface ExploreMapProps {
  complaints: Complaint[];
  selectedId: string | null;
  onSelectComplaint: (complaintId: string) => void;
  heightClass?: string;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function createPinIcon(color: string, isSelected: boolean): L.DivIcon {
  const size = isSelected ? 22 : 16;
  const ring = isSelected ? 'box-shadow: 0 0 0 4px rgba(29, 78, 216, 0.28);' : 'box-shadow: 0 2px 6px rgba(15, 23, 42, 0.35);';
  return L.divIcon({
    className: 'civicgrid-marker',
    html: `<div style="width:${size}px;height:${size}px;border-radius:9999px;background:${color};border:2.5px solid #ffffff;${ring}transition:transform 150ms ease;"></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });
}

export function ExploreLeafletMap({
  complaints,
  selectedId,
  onSelectComplaint,
  heightClass = 'h-[540px]',
}: ExploreMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const markersByIdRef = useRef<Map<string, L.Marker>>(new Map());

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [12.9716, 77.5946],
      zoom: 12,
      zoomControl: true,
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    mapRef.current = map;
    layerGroupRef.current = group;

    const timer = window.setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      window.clearTimeout(timer);
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
      markersByIdRef.current.clear();
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const group = layerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();
    markersByIdRef.current.clear();

    for (const c of complaints) {
      const color = getStatusDotColor(c.status);
      const isSelected = c.complaintId === selectedId;
      const marker = L.marker([c.latitude, c.longitude], {
        icon: createPinIcon(color, isSelected),
      });

      const safePhoto = escapeHtml(c.photoURL);
      const safeCategory = escapeHtml(c.category);
      const safeId = escapeHtml(c.complaintId);
      const safeArea = escapeHtml(c.area);
      const safeStatus = escapeHtml(c.status);
      const safePriority = escapeHtml(c.priority);

      marker.bindPopup(`
        <div style="width:248px;font-family:'Plus Jakarta Sans',sans-serif;">
          <img src="${safePhoto}" alt="${safeCategory}" style="width:100%;height:112px;object-fit:cover;display:block;border-bottom:1px solid #e2e8f0;" />
          <div style="padding:10px 12px;">
            <div style="font-family:'JetBrains Mono',monospace;font-size:11px;color:#475569;">${safeId}</div>
            <div style="font-weight:700;font-size:14px;color:#0f172a;margin-top:2px;">${safeCategory} · ${safeArea}</div>
            <div style="font-size:12px;color:#334155;margin-top:4px;">Status: <strong style="color:${color}">${safeStatus}</strong> · ${safePriority}</div>
          </div>
        </div>
      `);

      marker.on('click', () => {
        onSelectComplaint(c.complaintId);
      });

      marker.addTo(group);
      markersByIdRef.current.set(c.complaintId, marker);
    }
  }, [complaints, selectedId, onSelectComplaint]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedId) return;
    const target = complaints.find((c) => c.complaintId === selectedId);
    const marker = markersByIdRef.current.get(selectedId);
    if (target && marker) {
      map.panTo([target.latitude, target.longitude], { animate: true });
      marker.openPopup();
    }
  }, [selectedId, complaints]);

  return (
    <div
      ref={containerRef}
      className={`w-full ${heightClass} rounded-lg border border-slate-200 bg-slate-100 overflow-hidden`}
    />
  );
}

interface PickerMapProps {
  latitude: number;
  longitude: number;
  onChangeLocation: (lat: number, lng: number) => void;
  interactive?: boolean;
  heightClass?: string;
}

export function LocationPickerLeafletMap({
  latitude,
  longitude,
  onChangeLocation,
  interactive = true,
  heightClass = 'h-72',
}: PickerMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const onChangeRef = useRef(onChangeLocation);
  onChangeRef.current = onChangeLocation;

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [latitude, longitude],
      zoom: 15,
      zoomControl: true,
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const pinIcon = L.divIcon({
      className: 'civicgrid-picker-pin',
      html: `<div style="width:22px;height:22px;border-radius:9999px;background:#1d4ed8;border:3px solid #ffffff;box-shadow:0 3px 10px rgba(15,23,42,0.4);"></div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    });

    const marker = L.marker([latitude, longitude], {
      icon: pinIcon,
      draggable: interactive,
    }).addTo(map);

    if (interactive) {
      marker.on('dragend', () => {
        const pos = marker.getLatLng();
        onChangeRef.current(Number(pos.lat.toFixed(6)), Number(pos.lng.toFixed(6)));
      });

      map.on('click', (e: L.LeafletMouseEvent) => {
        onChangeRef.current(Number(e.latlng.lat.toFixed(6)), Number(e.latlng.lng.toFixed(6)));
      });
    }

    mapRef.current = map;
    markerRef.current = marker;

    const timer = window.setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      window.clearTimeout(timer);
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
  }, [interactive]);

  useEffect(() => {
    const map = mapRef.current;
    const marker = markerRef.current;
    if (!map || !marker) return;
    marker.setLatLng([latitude, longitude]);
    map.setView([latitude, longitude], map.getZoom(), { animate: true });
  }, [latitude, longitude]);

  return (
    <div
      ref={containerRef}
      className={`w-full ${heightClass} rounded-lg border border-slate-200 bg-slate-100 overflow-hidden`}
    />
  );
}
