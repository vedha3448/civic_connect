import { useEffect, useState } from 'react';
import { Check, Search } from 'lucide-react';
import type { AuthUser, Complaint } from '../types/civic';
import { COMPLAINT_STATUSES } from '../types/civic';
import {
  formatDateTime,
  formatShortDate,
  getPriorityTextClass,
  getStatusTextClass,
} from '../utils/statusStyles';
import { LocationPickerLeafletMap } from './LeafletMap';
import { SafeImage } from './SafeImage';

interface TrackViewProps {
  initialComplaintId: string | null;
  allComplaints: Complaint[];
  user: AuthUser | null;
}

export function TrackView({ initialComplaintId, allComplaints, user }: TrackViewProps) {
  const [queryId, setQueryId] = useState(initialComplaintId || 'CG-20261124-0001');
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const lookupComplaint = async (idToFetch: string) => {
    const clean = idToFetch.trim().toUpperCase();
    if (!clean) {
      setError('Enter a complaint ID such as CG-20261124-0001.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/complaints/${encodeURIComponent(clean)}`);
      const data = await res.json();
      if (!res.ok) {
        setComplaint(null);
        setError(data.error || `No complaint found with ID "${clean}".`);
        return;
      }
      setComplaint(data.complaint as Complaint);
    } catch {
      setError('Unable to look up complaint status right now.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialComplaintId) {
      setQueryId(initialComplaintId);
      void lookupComplaint(initialComplaintId);
    } else if (!complaint && allComplaints.length > 0) {
      const firstId = allComplaints[0].complaintId;
      setQueryId(firstId);
      setComplaint(allComplaints[0]);
    }
  }, [initialComplaintId]);

  // Keep currently viewed complaint synced with live SSE updates
  useEffect(() => {
    if (!complaint) return;
    const updated = allComplaints.find((c) => c.complaintId === complaint.complaintId);
    if (updated && updated.updatedAt !== complaint.updatedAt) {
      setComplaint(updated);
    }
  }, [allComplaints, complaint]);

  const myComplaints = user
    ? allComplaints.filter((c) => c.userId === user.uid)
    : [];

  const currentStageIndex = complaint
    ? COMPLAINT_STATUSES.indexOf(complaint.status)
    : -1;

  return (
    <div className="max-w-[1160px] mx-auto px-4 sm:px-6 py-8">
      <div className="pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
          Track Complaint Progress
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Enter any CivicGrid Complaint ID to view real-time status, assigned department, and
          resolution history.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void lookupComplaint(queryId);
          }}
          className="mt-5 flex flex-col sm:flex-row gap-3 max-w-xl"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={queryId}
              onChange={(e) => setQueryId(e.target.value)}
              placeholder="Enter Complaint ID (e.g. CG-20261124-0001)"
              className="w-full pl-10 pr-4 py-2.5 text-sm font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            {loading ? 'Checking...' : 'Check Status'}
          </button>
        </form>

        {/* Quick sample complaint IDs */}
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-500">
          <span>Recent IDs:</span>
          {allComplaints.slice(0, 5).map((c) => (
            <button
              key={c.complaintId}
              type="button"
              onClick={() => {
                setQueryId(c.complaintId);
                void lookupComplaint(c.complaintId);
              }}
              className={`font-mono px-2 py-1 rounded border transition-colors ${
                complaint?.complaintId === c.complaintId
                  ? 'border-blue-700 bg-blue-50 text-blue-800 font-semibold'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
            >
              {c.complaintId}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mt-6 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
          {error}
        </div>
      )}

      {complaint && (
        <div className="mt-8 space-y-6">
          {/* Status Progress Bar Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-200">
              <div>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
                  <span className="font-mono font-semibold text-slate-900">
                    {complaint.complaintId}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{complaint.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className={getPriorityTextClass(complaint.priority)}>
                    {complaint.priority} Priority
                  </span>
                </div>
                <h2 className="mt-1 font-display text-xl font-bold text-slate-950">
                  {complaint.area}
                </h2>
              </div>

              <div className="text-left sm:text-right">
                <div className="text-xs text-slate-500">Current Stage</div>
                <div className={`text-base font-bold ${getStatusTextClass(complaint.status)}`}>
                  {complaint.status}
                </div>
              </div>
            </div>

            {/* 5-Stage Horizontal Progress Stepper */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-5 gap-3">
              {COMPLAINT_STATUSES.map((stage, index) => {
                const completed = index <= currentStageIndex;
                const isCurrent = index === currentStageIndex;
                return (
                  <div
                    key={stage}
                    className={`p-3 rounded-lg border ${
                      isCurrent
                        ? 'border-blue-700 bg-blue-50/70'
                        : completed
                        ? 'border-emerald-200 bg-emerald-50/40'
                        : 'border-slate-200 bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs text-slate-500 tabular-nums">
                        0{index + 1}
                      </span>
                      {completed && (
                        <Check
                          className={`w-4 h-4 ${
                            isCurrent ? 'text-blue-700' : 'text-emerald-700'
                          }`}
                        />
                      )}
                    </div>
                    <div
                      className={`mt-1.5 text-xs font-semibold ${
                        isCurrent
                          ? 'text-blue-900'
                          : completed
                          ? 'text-slate-900'
                          : 'text-slate-500'
                      }`}
                    >
                      {stage}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Details Grid: Evidence & Timeline vs Map Location */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <h3 className="font-display text-base font-bold text-slate-950">
                  Complaint Details
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-700">
                  {complaint.description}
                </p>

                <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-200 text-xs">
                  <div>
                    <div className="text-slate-500">Reported By</div>
                    <div className="font-semibold text-slate-900 mt-0.5">
                      {complaint.reporterName}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Assigned Department</div>
                    <div className="font-semibold text-slate-900 mt-0.5">
                      {complaint.assignedDepartment || 'Pending Assignment'}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Submitted On</div>
                    <div className="font-mono text-slate-900 mt-0.5 tabular-nums">
                      {formatShortDate(complaint.createdAt)}
                    </div>
                  </div>
                </div>

                {complaint.adminNotes && (
                  <div className="mt-4 p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                    <div className="font-semibold text-slate-900">Latest Official Note</div>
                    <p className="mt-1 text-slate-700">{complaint.adminNotes}</p>
                  </div>
                )}
              </div>

              {/* Activity Timeline */}
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <h3 className="font-display text-base font-bold text-slate-950 mb-4">
                  Status Audit History
                </h3>
                <div className="space-y-4">
                  {[...complaint.statusHistory].reverse().map((entry, idx) => (
                    <div
                      key={`${entry.status}-${entry.updatedAt}-${idx}`}
                      className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100 last:border-b-0 last:pb-0"
                    >
                      <div>
                        <div className={`text-sm font-semibold ${getStatusTextClass(entry.status)}`}>
                          {entry.status}
                        </div>
                        <p className="mt-0.5 text-xs text-slate-700">{entry.note}</p>
                        <div className="mt-1 text-xs text-slate-500">
                          Updated by {entry.updatedBy}
                        </div>
                      </div>
                      <div className="font-mono text-xs text-slate-500 whitespace-nowrap shrink-0 tabular-nums">
                        {formatDateTime(entry.updatedAt)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-200 text-sm font-semibold text-slate-950">
                  Photographic Evidence
                </div>
                <div className="h-60 bg-slate-100">
                  <SafeImage
                    src={complaint.photoURL}
                    alt={`${complaint.category} evidence`}
                    className="w-full h-full object-cover"
                    fallbackLabel={complaint.category}
                  />
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="font-semibold text-slate-950 text-sm">Pinned Location</span>
                  <span className="font-mono text-slate-600 tabular-nums">
                    {complaint.latitude.toFixed(5)}, {complaint.longitude.toFixed(5)}
                  </span>
                </div>
                <LocationPickerLeafletMap
                  latitude={complaint.latitude}
                  longitude={complaint.longitude}
                  onChangeLocation={() => {}}
                  interactive={false}
                  heightClass="h-56"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User's own reports */}
      {myComplaints.length > 0 && (
        <div className="mt-10 bg-white border border-slate-200 rounded-xl p-6">
          <h2 className="font-display text-lg font-bold text-slate-950">
            My Submitted Complaints
          </h2>
          <div className="mt-4 divide-y divide-slate-200">
            {myComplaints.map((c) => (
              <div
                key={c.complaintId}
                className="py-3 flex items-center justify-between gap-4 text-sm"
              >
                <div className="min-w-0">
                  <span className="font-mono text-xs font-semibold text-slate-700 mr-2">
                    {c.complaintId}
                  </span>
                  <span className="font-medium text-slate-950">
                    {c.category} · {c.area}
                  </span>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className={`text-xs font-semibold ${getStatusTextClass(c.status)}`}>
                    {c.status}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setQueryId(c.complaintId);
                      void lookupComplaint(c.complaintId);
                    }}
                    className="text-xs font-semibold text-blue-700 hover:underline"
                  >
                    Inspect
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
