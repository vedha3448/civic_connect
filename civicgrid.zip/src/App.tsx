import { useCallback, useEffect, useState } from 'react';
import { AdminView } from './components/AdminView';
import { AuthView } from './components/AuthView';
import { ExploreView } from './components/ExploreView';
import { HomeView } from './components/HomeView';
import { type ActivePage, Navbar } from './components/Navbar';
import { ReportView } from './components/ReportView';
import { TrackView } from './components/TrackView';
import type {
  AnalyticsSummary,
  AuthUser,
  Complaint,
  IssueCategory,
} from './types/civic';

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedCategoryForReport, setSelectedCategoryForReport] =
    useState<IssueCategory>('Pothole');
  const [trackTargetId, setTrackTargetId] = useState<string | null>(null);
  const [returnAfterAuth, setReturnAfterAuth] = useState<ActivePage>('home');

  const fetchComplaints = useCallback(async () => {
    try {
      const res = await fetch('/api/complaints');
      const data = await res.json();
      if (!res.ok) {
        setLoadError(data.error || 'Failed to load civic reports.');
        return;
      }
      setComplaints(data.complaints || []);
      setAnalytics(data.analytics || null);
      setLoadError(null);
    } catch {
      setLoadError('Unable to connect to CivicGrid server.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchComplaints();
  }, [fetchComplaints]);

  // Subscribe to live Server-Sent Events for real-time public and admin updates
  useEffect(() => {
    const source = new EventSource('/api/events');

    const handleRefresh = () => {
      void fetchComplaints();
    };

    source.addEventListener('complaint_created', handleRefresh);
    source.addEventListener('complaint_updated', handleRefresh);

    return () => {
      source.removeEventListener('complaint_created', handleRefresh);
      source.removeEventListener('complaint_updated', handleRefresh);
      source.close();
    };
  }, [fetchComplaints]);

  const handleNavigate = (page: ActivePage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAuthenticated = (authUser: AuthUser, authToken: string) => {
    setUser(authUser);
    setToken(authToken);
    if (authUser.role === 'admin' && activePage === 'admin') {
      return;
    }
    if (authUser.role === 'admin') {
      handleNavigate('admin');
      return;
    }
    handleNavigate(returnAfterAuth === 'auth' ? 'home' : returnAfterAuth);
  };

  const handleSignOut = () => {
    setUser(null);
    setToken(null);
    if (activePage === 'admin') {
      handleNavigate('home');
    }
  };

  const handleTrackId = (complaintId: string) => {
    setTrackTargetId(complaintId);
    handleNavigate('track');
  };

  const handleReportCategory = (category: IssueCategory) => {
    setSelectedCategoryForReport(category);
    handleNavigate('report');
  };

  const handleUpvote = async (complaintId: string) => {
    if (!token) {
      setReturnAfterAuth('explore');
      handleNavigate('auth');
      return;
    }
    const res = await fetch(`/api/complaints/${encodeURIComponent(complaintId)}/upvote`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (res.ok) {
      await fetchComplaints();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar
        activePage={activePage}
        onNavigate={handleNavigate}
        user={user}
        onSignOut={handleSignOut}
      />

      {loadError && (
        <div className="bg-red-50 border-b border-red-200 text-red-800 text-sm px-4 py-2.5 text-center">
          {loadError}
        </div>
      )}

      <main className="flex-1">
        {loading && complaints.length === 0 ? (
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-16">
            <div className="animate-pulse space-y-6">
              <div className="h-10 bg-slate-200 rounded w-1/2" />
              <div className="h-64 bg-slate-200 rounded-xl" />
            </div>
          </div>
        ) : (
          <>
            {activePage === 'home' && (
              <HomeView
                analytics={analytics}
                recentComplaints={complaints}
                onNavigate={handleNavigate}
                onReportCategory={handleReportCategory}
                onTrackId={handleTrackId}
              />
            )}

            {activePage === 'explore' && (
              <ExploreView
                complaints={complaints}
                analytics={analytics}
                user={user}
                onTrackId={handleTrackId}
                onUpvote={handleUpvote}
                onRequireSignIn={() => {
                  setReturnAfterAuth('explore');
                  handleNavigate('auth');
                }}
              />
            )}

            {activePage === 'report' && (
              <ReportView
                user={user}
                token={token}
                initialCategory={selectedCategoryForReport}
                onRequireSignIn={() => {
                  setReturnAfterAuth('report');
                  handleNavigate('auth');
                }}
                onComplaintCreated={() => {
                  void fetchComplaints();
                }}
                onTrackId={handleTrackId}
              />
            )}

            {activePage === 'track' && (
              <TrackView
                initialComplaintId={trackTargetId}
                allComplaints={complaints}
                user={user}
              />
            )}

            {activePage === 'admin' && (
              <AdminView
                user={user}
                token={token}
                complaints={complaints}
                analytics={analytics}
                onAuthenticated={handleAuthenticated}
                onComplaintUpdated={() => {
                  void fetchComplaints();
                }}
                onBackHome={() => handleNavigate('home')}
              />
            )}

            {activePage === 'auth' && (
              <AuthView
                onAuthenticated={handleAuthenticated}
                onBackHome={() => handleNavigate('home')}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
