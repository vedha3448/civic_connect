# CivicGrid — Civic Issue Reporting Prototype

CivicGrid is a responsive front-end prototype for reporting potholes, damaged roads, garbage accumulation and broken streetlights.

## Run the project
1. Extract the ZIP file.
2. Open the `CivicGrid` folder.
3. Double-click `index.html`, or use VS Code with the Live Server extension.
4. Try submitting a report. Reports are stored in your browser's local storage.

## Included features
- Responsive landing page
- Issue report form with category and description
- Optional photo evidence preview (maximum 4 MB)
- Browser geolocation with manual landmark/address field
- Community report cards
- Search and category/status filters
- Demo report IDs and local status labels

## Important prototype limitations
- This is a front-end demonstration. Reports stay in the browser that submitted them; they are not sent to a municipality or shared with other users.
- There is no real citizen account, admin authentication, cloud database, or authority workflow yet.
- Browser geolocation generally requires HTTPS or localhost and the user's permission.
- Do not use a client-side passcode as real admin security. A production admin area must verify identity and permissions on a trusted backend.

## Suggested next development phase
Connect Firebase (Authentication, Firestore and Storage) or another backend, implement secure admin roles, and establish an authorized workflow with the relevant civic body before describing reports as officially submitted.
