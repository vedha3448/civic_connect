const STORAGE_KEY = "civicgrid-demo-reports";
const $ = (id) => document.getElementById(id);
const reportDialog = $("reportDialog");
let selectedPhoto = "";
let coords = null;

const starterReports = [
  {id:"CG-240101",category:"Pothole",description:"Large pothole reported near the junction. Please inspect the road surface.",location:"Sample: 4th Block, Jayanagar",status:"Under review",date:new Date(Date.now()-86400000*2).toISOString(),photo:"",lat:null,lng:null},
  {id:"CG-240102",category:"Garbage",description:"Garbage has accumulated beside the public bin.",location:"Sample: Indiranagar",status:"Pending",date:new Date(Date.now()-86400000).toISOString(),photo:"",lat:null,lng:null},
  {id:"CG-240103",category:"Broken streetlight",description:"Streetlight is not working near the pedestrian crossing.",location:"Sample: Malleshwaram",status:"Resolved",date:new Date(Date.now()-86400000*5).toISOString(),photo:"",lat:null,lng:null}
];

function getReports(){
  try { const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)); return Array.isArray(saved)?saved:starterReports; }
  catch { return starterReports; }
}
function saveReports(reports){ localStorage.setItem(STORAGE_KEY,JSON.stringify(reports)); }
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function dateLabel(value){return new Date(value).toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});}
function statusClass(status){return status==="Resolved"?"resolved":status==="Pending"?"pending":"";}
function render(){
  const reports=getReports();
  $("heroCount").textContent=reports.length;
  $("heroOpen").textContent=reports.filter(r=>r.status!=="Resolved").length;
  $("heroResolved").textContent=reports.filter(r=>r.status==="Resolved").length;
  const q=$("searchReports").value.toLowerCase();
  const cat=$("filterCategory").value, status=$("filterStatus").value;
  const filtered=reports.filter(r=>(cat==="all"||r.category===cat)&&(status==="all"||r.status===status)&&[r.id,r.category,r.description,r.location].join(" ").toLowerCase().includes(q));
  $("reportGrid").innerHTML=filtered.map(r=>`<article class="report-card">
    <div class="report-photo">${r.photo?`<img src="${r.photo}" alt="Evidence for ${escapeHTML(r.category)}">`:"📍"}</div>
    <div class="report-body"><div class="report-top"><span class="tag">${escapeHTML(r.category)}</span><span class="status ${statusClass(r.status)}">${escapeHTML(r.status)}</span></div>
    <h3>${escapeHTML(r.description.slice(0,68))}${r.description.length>68?"…":""}</h3><p>⌖ ${escapeHTML(r.location)}</p>
    <div class="report-meta"><span>${escapeHTML(r.id)}</span><span>${dateLabel(r.date)}</span></div></div></article>`).join("");
  $("emptyState").hidden=filtered.length!==0;
}
function openReport(){ $("formMessage").textContent=""; reportDialog.showModal(); }
["openReportTop","openReportHero","openReportList","openReportBottom"].forEach(id=>$(id).addEventListener("click",openReport));
$("closeReport").addEventListener("click",()=>reportDialog.close());
$("searchReports").addEventListener("input",render);
$("filterCategory").addEventListener("change",render);
$("filterStatus").addEventListener("change",render);

$("getLocation").addEventListener("click",()=>{
  if(!navigator.geolocation){$("locationStatus").textContent="Geolocation is not supported by this browser.";return;}
  $("locationStatus").textContent="Getting location…";
  navigator.geolocation.getCurrentPosition(pos=>{
    coords={lat:pos.coords.latitude,lng:pos.coords.longitude};
    $("latitude").value=coords.lat;$("longitude").value=coords.lng;
    $("locationStatus").textContent=`Location added (${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)})`;
  },()=>{$("locationStatus").textContent="Could not get location. Enter a nearby landmark instead."},{enableHighAccuracy:true,timeout:10000});
});
$("photo").addEventListener("change",e=>{
  const file=e.target.files[0]; selectedPhoto="";
  if(!file){$("photoPreview").hidden=true;return;}
  if(!file.type.startsWith("image/")){alert("Please choose an image file.");e.target.value="";return;}
  if(file.size>4*1024*1024){alert("Please choose an image smaller than 4 MB.");e.target.value="";return;}
  const reader=new FileReader();
  reader.onload=()=>{selectedPhoto=reader.result;$("photoPreview").src=selectedPhoto;$("photoPreview").hidden=false;};
  reader.readAsDataURL(file);
});
$("reportForm").addEventListener("submit",e=>{
  e.preventDefault();
  const category=$("category").value,description=$("description").value.trim(),location=$("locationText").value.trim();
  if(!category||!description||!location)return;
  const report={id:"CG-"+Math.floor(100000+Math.random()*900000),category,description,location,status:"Pending",date:new Date().toISOString(),photo:selectedPhoto,lat:coords?.lat??null,lng:coords?.lng??null};
  const reports=getReports();reports.unshift(report);
  try{saveReports(reports);}catch(err){$("formMessage").textContent="Browser storage is full. Try submitting without a photo.";return;}
  $("formMessage").textContent=`Report submitted! Your demo report ID is ${report.id}.`;
  $("reportForm").reset();selectedPhoto="";coords=null;$("photoPreview").hidden=true;$("locationStatus").textContent="Location not added";
  render();
  setTimeout(()=>reportDialog.close(),1500);
});
render();
